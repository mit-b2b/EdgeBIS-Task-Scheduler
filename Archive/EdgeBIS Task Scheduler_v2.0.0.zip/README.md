Lizenzhinweis:
Dieses Projekt verwendet die Schriftart Montserrat, die unter der SIL Open Font License (OFL) lizenziert ist. Den
vollständigen Lizenztext finden Sie in der Datei LICENSE im Projektverzeichnis oder unter
diesem https://scripts.sil.org/cms/scripts/page.php?item_id=OFL_web Link.